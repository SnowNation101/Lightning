package cn.bupt.lightning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LightningApplicationTests {

  @Test
  void contextLoads() {
  }

}
