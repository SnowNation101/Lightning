package cn.bupt.lightning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LightningApplication {

  public static void main(String[] args) {
    SpringApplication.run(LightningApplication.class, args);
  }

}
