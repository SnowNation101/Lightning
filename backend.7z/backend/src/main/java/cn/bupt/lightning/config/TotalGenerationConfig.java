package cn.bupt.lightning.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class TotalGenerationConfig {
//  @Bean
//  CommandLineRunner commandLineRunner(TotalGenerationRepo totalGenerationRepo) {
//    return args -> {
//      TotalGeneration t0 = new TotalGeneration(
//          1,
//          LocalDate.of(2022, 10, 14),
//          38.23f
//      );
//
//      TotalGeneration t1 = new TotalGeneration(
//          1,
//          LocalDate.of(2022, 10, 1),
//          1234.23f
//      );
//
//      TotalGeneration t2 = new TotalGeneration(
//          1,
//          LocalDate.of(2022, 9, 22),
//          983.84f
//      );
//
//      TotalGeneration t3 = new TotalGeneration(
//          1,
//          LocalDate.of(2022, 8, 4),
//          45123.84f
//      );
//      TotalGeneration t4 = new TotalGeneration(
//          1,
//          LocalDate.of(2022, 7, 25),
//          91243.84f
//      );
//      TotalGeneration t5 = new TotalGeneration(
//          1,
//          LocalDate.of(2022, 6, 4),
//          98223.84f
//      );
//      TotalGeneration t6 = new TotalGeneration(
//          1,
//          LocalDate.of(2022, 5, 19),
//          1845153.84f
//      );
//      TotalGeneration t7 = new TotalGeneration(
//          1,
//          LocalDate.of(2022, 4, 8),
//          22983.84f
//      );
//      TotalGeneration t8 = new TotalGeneration(
//          1,
//          LocalDate.of(2022, 3, 1),
//          33333983.84f
//      );
//      TotalGeneration t9 = new TotalGeneration(
//          1,
//          LocalDate.of(2022, 2, 22),
//          4983.84f
//      );
//      TotalGeneration t10 = new TotalGeneration(
//          1,
//          LocalDate.of(2022, 1, 20),
//          5555983.84f
//      );
//      TotalGeneration t11 = new TotalGeneration(
//          1,
//          LocalDate.of(2021, 12, 16),
//          667983.84f
//      );
//      TotalGeneration t12 = new TotalGeneration(
//          1,
//          LocalDate.of(2021, 11, 10),
//          444983.84f
//      );
//      TotalGeneration t13 = new TotalGeneration(
//          1,
//          LocalDate.of(2022, 9, 10),
//          1.84f
//      );
//
//      totalGenerationRepo.saveAll(
//          Arrays.asList(t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13)
//      );
//    };
//  }
}
